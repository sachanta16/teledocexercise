# teledoc
Import the project as Maven 
In Package explorer right clinck on the project and run Maven-> Update Project
To run the test cases, right click on TestRunner class and use run as junit Test

Write the test cases, in adduser.feature file under Features
Each feature file will be having a stepdefinition file under StepDefinition package
Make sure the chrome browser version as 95
